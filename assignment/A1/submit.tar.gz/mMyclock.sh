./myclock.sh outA&
./myclock.sh outB&
./myclock.sh outC&
wait
