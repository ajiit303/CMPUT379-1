#include <stdarg.h>

#ifndef HANDLER_H
#define HANDLER_H

void warning ( const char *fmt, ... );

void fatal ( const char *fmt, ... );

#endif
